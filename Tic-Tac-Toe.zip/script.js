const cellElements = document.querySelectorAll('[data-cell]');
let currentPlayer = 'X';
let gameActive = true;

cellElements.forEach(cell => {
  cell.addEventListener('click', handleCellClick);
});

function handleCellClick(e) {
  const cell = e.target;

  if (!gameActive || cell.textContent !== '') {
    return;
  }

  cell.textContent = currentPlayer;
  if (checkWin()) {
    endGame(`Player ${currentPlayer} wins!`);
  } else if (checkDraw()) {
    endGame('Draw!');
  } else {
    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
  }
}

function checkWin() {
  // Logic to check for a win
}

function checkDraw() {
  // Logic to check for a draw
}

function endGame(message) {
  gameActive = false;
  document.getElementById('status').textContent = message;
}

document.getElementById('restart').addEventListener('click', () => {
  cellElements.forEach(cell => {
    cell.textContent = '';
  });
  document.getElementById('status').textContent = '';
  currentPlayer = 'X';
  gameActive = true;
});
function checkWin() {
  const winConditions = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
    [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
    [0, 4, 8], [2, 4, 6]             // Diagonals
  ];

  return winConditions.some(condition => {
    const [a, b, c] = condition;
    return (
      cellElements[a].textContent === currentPlayer &&
      cellElements[b].textContent === currentPlayer &&
      cellElements[c].textContent === currentPlayer
    );
  });
}
// Inside the handleCellClick() function
function handleCellClick(e) {
  const cell = e.target;

  if (!gameActive || cell.textContent !== '') {
    return;
  }

  cell.textContent = currentPlayer;
  if (checkWin()) {
    endGame(`Player ${currentPlayer} wins!`);
  } else if (checkDraw()) {
    endGame('Draw!');
  } else {
    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    document.getElementById('turn').textContent = `Current Turn: ${currentPlayer}`;
  }
}
function handleCellClick(e) {
  const cell = e.target;

  if (!gameActive || cell.textContent !== '') {
    return;
  }

  cell.textContent = currentPlayer;
  if (checkWin()) {
    endGame(`Player ${currentPlayer} wins!`);
  } else if (checkDraw()) {
    endGame('Draw!');
  } else {
    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
    document.getElementById('turn').textContent = `Current Turn: ${currentPlayer}`;
    if (checkDraw()) {
      endGame('Draw!');
    }
  }
}

function checkDraw() {
  return [...cellElements].every(cell => cell.textContent !== '');
}
